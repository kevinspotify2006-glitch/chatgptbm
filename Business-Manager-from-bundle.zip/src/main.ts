import './ui/styles.css';
import type { GameState } from './sim/state';
import { playerBusinesses } from './sim/state';
import { Engine } from './sim/engine';
import { unreadAlerts } from './sim/alerts';
import { App } from './ui/app';
import { showWelcome } from './ui/welcome';
import { dashboardView } from './ui/views/dashboard';
import { mapView } from './ui/views/mapView';
import { businessesView } from './ui/views/businesses';
import { employeesView } from './ui/views/employees';
import { inventoryView } from './ui/views/inventory';
import { marketingView } from './ui/views/marketing';
import { financeView } from './ui/views/finance';
import { propertyView } from './ui/views/property';
import { reportsView } from './ui/views/reports';
import { settingsView } from './ui/views/settings';

const root = document.getElementById('app');
if (!root) throw new Error('#app is missing from the page');

let app: App | null = null;

function boot(state: GameState): void {
  app?.stop();
  const engine = new Engine(state);
  app = new App(root as HTMLElement, engine);

  app.register({ route: 'dashboard', label: 'Dashboard', icon: '▦', factory: dashboardView });
  app.register({ route: 'map', label: 'Map', icon: '🗺', factory: mapView });
  app.register({
    route: 'businesses',
    label: 'Businesses',
    icon: '🏬',
    factory: businessesView,
    badge: (s) => playerBusinesses(s).filter((b) => b.status === 'setup').length,
  });
  app.register({ route: 'employees', label: 'Employees', icon: '👥', factory: employeesView });
  app.register({ route: 'inventory', label: 'Inventory', icon: '📦', factory: inventoryView });
  app.register({ route: 'marketing', label: 'Marketing', icon: '📣', factory: marketingView });
  app.register({ route: 'finance', label: 'Finance', icon: '💶', factory: financeView });
  app.register({ route: 'property', label: 'Real estate', icon: '🏢', factory: propertyView });
  app.register({
    route: 'reports',
    label: 'Reports',
    icon: '📊',
    factory: reportsView,
    badge: (s) => unreadAlerts(s).filter((a) => a.priority !== 'info').length,
  });
  app.register({ route: 'settings', label: 'Settings', icon: '⚙', factory: settingsView });

  app.start();
}

showWelcome(root as HTMLElement, boot);
